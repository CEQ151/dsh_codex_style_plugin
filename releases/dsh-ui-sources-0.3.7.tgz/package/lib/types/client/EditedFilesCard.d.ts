import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { TurnTailOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { FileChangesTurnData } from './turn-file-changes.ts';
import { NS } from './locales.ts';
export interface EditedFilesCardProps extends PropsLocale<typeof NS> {
    /** Chat view's file opener. */
    openFile: TurnTailOwnerProps['openFile'];
    /** Chain-selected file changes for this turn. */
    matched: FileChangesTurnData;
}
export declare function EditedFilesCard({ openFile, matched, t, }: EditedFilesCardProps): ReactNode;
