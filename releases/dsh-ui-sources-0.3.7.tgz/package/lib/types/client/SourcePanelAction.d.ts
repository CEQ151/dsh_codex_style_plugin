import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { OpenLocalPath, SourcesPanelController } from './controller.ts';
import { NS } from './locales.ts';
export interface SourcesPanelInjected {
    openLocalPath: OpenLocalPath;
    panel: SourcesPanelController;
}
export type SourcesPanelProps = PropsRuntime<'conversation.session.header.utilities'> & PropsLocale<typeof NS> & InjectFace<SourcesPanelInjected>;
export declare function SourcePanelAction({ sessionId, useProjection, useSessions, openLocalPath, panel, t, }: SourcesPanelProps): ReactNode;
