import { type CSSProperties, type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SourceItem } from '../types.ts';
import type { OpenLocalPath } from './controller.ts';
import { NS } from './locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
export interface SourcesDetailsInjected {
    closeSources: () => void;
    openLocalPath: OpenLocalPath;
}
export type SourcesDetailsProps = PropsRuntime<'details'> & PropsLocale<typeof NS> & InjectFace<SourcesDetailsInjected>;
interface PanelRuntimeProps {
    cwd: string | undefined;
    openLocalPath: OpenLocalPath;
    t: Translate;
}
interface CompactPanelProps extends PanelRuntimeProps {
    items: SourceItem[];
    style: CSSProperties;
    onClose: () => void;
}
interface CardPanelProps extends PanelRuntimeProps {
    items: SourceItem[];
    onViewAll: () => void;
}
export declare function SourcesDetailsPanel({ sessionId, useProjection, useSessions, openLocalPath, closeSources, t, }: SourcesDetailsProps): ReactNode;
/** The resident top-right card: briefly lists referenced sources, one per
  * single line, with a "view all sources" action that opens the sidebar. */
export declare function SourcesCard({ items, cwd, openLocalPath, t, onViewAll, }: CardPanelProps): ReactNode;
export declare const SourcesCompactPanel: import("react").ForwardRefExoticComponent<CompactPanelProps & import("react").RefAttributes<HTMLDivElement>>;
export {};
