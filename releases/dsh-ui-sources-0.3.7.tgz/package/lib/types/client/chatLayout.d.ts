import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare function installChatLayout(ctx: ClientContext): void;
