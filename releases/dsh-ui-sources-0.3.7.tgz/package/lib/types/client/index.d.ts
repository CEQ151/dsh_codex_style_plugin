import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type SourcesLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'ui-sources': SourcesLocaleKey;
    }
}
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
export type { SourcesPanelInjected, SourcesPanelProps } from './SourcePanelAction.tsx';
export type { SourcesDetailsInjected, SourcesDetailsProps } from './SourcesPanels.tsx';
export type { SourcesPanelState } from './controller.ts';
