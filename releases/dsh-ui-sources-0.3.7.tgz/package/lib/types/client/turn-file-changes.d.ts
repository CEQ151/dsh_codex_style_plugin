import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
import type { TurnTailOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { FileChange } from '../types.ts';
interface PendingCall {
    name: string;
    args: Record<string, unknown>;
}
export interface FileChangesTurnData {
    turn: number;
    files: FileChange[];
}
declare module '@deepseek-ai/dsh-client-runtime/client' {
    interface ConversationTurnDataMap {
        /** Per-turn file-change summary accumulated by dsh-ui-sources. */
        fileChanges: FileChangesTurnData;
    }
}
interface FileChangesState {
    turn: number;
    pendingCalls: Map<string, PendingCall>;
    byPath: Record<string, FileChange>;
}
export declare const fileChangesDefinition: ConversationNodeDefinition<FileChangesState>;
export declare function selectFileChanges(owner: TurnTailOwnerProps): FileChangesTurnData | null;
export {};
