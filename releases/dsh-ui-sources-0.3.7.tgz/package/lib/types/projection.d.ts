import { z } from 'zod';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { FileChange, FileDiff, SourceItem, SourceProjection } from './types.ts';
interface PendingCall {
    name: string;
    args: Record<string, unknown>;
    seq: number;
    turn: number;
}
export interface SourcesState {
    items: Record<string, SourceItem>;
    pendingCalls: Record<string, PendingCall>;
    assistantTextByTurn: Record<string, string>;
    /** File-diff hunks collected per turn, keyed by turn then normalized path. */
    changesByTurn: Record<string, Record<string, FileChange>>;
    published: SourceProjection;
    nextSeenSeq: number;
    nextReferenceOrder: number;
}
export declare const sourceProjectionSchema: z.ZodType<SourceProjection>;
export declare function createSourcesState(): SourcesState;
export declare function canonicalizeUrl(raw: string): string | undefined;
export declare function diffHunksFromCall(name: string, args: Record<string, unknown>): FileDiff[];
export declare function diffHunksFromMeta(meta: unknown): FileDiff[];
export declare function applySourcesEvent(state: SourcesState, event: SessionEvent): SourcesState;
export declare const sourcesProjectionDefinition: {
    key: "sources";
    schema: z.ZodType<SourceProjection, unknown, z.core.$ZodTypeInternals<SourceProjection, unknown>>;
    init: typeof createSourcesState;
    apply: typeof applySourcesEvent;
    view: (state: SourcesState) => SourceProjection;
    stateVersion: number;
};
export {};
