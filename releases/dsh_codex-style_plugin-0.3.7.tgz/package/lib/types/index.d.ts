import type { Context } from '@deepseek-ai/cordis';
export type * from './types.ts';
export { applySourcesEvent, canonicalizeUrl, createSourcesState, sourcesProjectionDefinition } from './projection.ts';
export declare const name = "codex-style";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
