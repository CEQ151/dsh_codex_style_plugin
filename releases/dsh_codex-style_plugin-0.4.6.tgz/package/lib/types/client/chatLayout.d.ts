import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export declare const CARD_WIDTH = 340;
export declare const CARD_MARGIN_RIGHT = 16;
export declare const TRACK_INSET = 0;
export declare const CONTENT_PADDING = 32;
export declare const MIN_GAP = 12;
export declare const CHAT_MAX_WIDTH = 860;
export declare const CHAT_MIN_WIDTH = 520;
export declare const SIDEBAR_EXPANDED_WIDTH = 280;
export declare const SIDEBAR_COLLAPSED_WIDTH = 56;
export interface ChatLayoutInput {
    /** Scrollport left edge when the sidebar is expanded (absolute px). */
    expandedLeft: number;
    /** Scrollport right edge (absolute px). */
    expandedRight: number;
    /** Current scrollport left edge (absolute px). */
    currentLeft: number;
    /** Whether the resident sources card is currently mounted. */
    cardVisible: boolean;
    cardWidth?: number;
    cardMarginRight?: number;
    trackInset?: number;
    minGap?: number;
    chatMaxWidth?: number;
    chatMinWidth?: number;
}
export interface ChatLayoutResult {
    /** Stable left boundary of the conversation track (absolute px). */
    stableLeft: number;
    /** Card left edge when visible; otherwise null. */
    cardLeft: number | null;
    cardWidth: number;
    /** Absolute left edge of the chat lane. */
    chatLeft: number;
    /** Chat lane width. */
    chatWidth: number;
    /** Absolute right edge of the chat lane. */
    chatRight: number;
    /** Distance from the current sidebar right edge to the chat left edge. */
    leftGap: number;
    /** Distance from chat right edge to card left edge when card is visible. */
    rightGap: number | null;
    /** True when the card would overlap / crowd the chat at this width. */
    wouldOverlap: boolean;
}
export declare function computeChatLayout(input: ChatLayoutInput): ChatLayoutResult;
export declare function installChatLayout(ctx: ClientContext): void;
